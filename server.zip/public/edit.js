// ==========================
// 🏥 Facility Mapping
// ==========================
const facilityMap = {
  "Kotobabi": ["Anthon Memorial Hospital", "Anthon Memorial Hospital Annex", "Effan Victory Clinic", "Life View Medical Hospital", 
              "Anthon CHPS", "Bright Star CHPS", "Ebony Down CHPS", "Pigfarm CHPS", "Anthon Annex CHPS", "Great Gerraldo CHPS"
              ],
  "Accra New Town": ["Ghanuba Specialist Hospital", "Medylife Healthcare (Clinix)", "Mercy Ana’s Maternity Home", "Mission Clinic", 
                    "Mustard Health Systems and", "Fertility Centre (Sape Agbo)", "Gift Medical Centre", "Apostolic CHPS", 
                    "Mrs. Dua CHPS", "Ayidiki CHPS", "Wisdom CHPS"
                    ],
  "Alajo": ["Alajo Community Clinic", "Unfolding Glory Medical Centre", "Alajo Park CHPS", "Delape CHPS", "High Tension CHPS", 
            "Pele CHPS", "Polo Park CHPS"
          ],
  "Kokomlemle": ["Entrance University Hospital", "Mallam Atta Government Clinic", "Mariestopes International Ghana", 
                "Salvation Army Anidasofie Clinic", "Holy Heights Clinic ", "Anidasofie CHPS", "De-youngsters CHPS", 
                "New Page CHPS", "Mallam Atta CHPS", "Tip Toe CHPS"
                ]
};

// ==========================
// 📋 List of Project Names (15 forms)
// ==========================
const projectNames = [
  "Clinical Care",
  "Nutrition Services",
  "Expanded Program of Immunisation, Surveillance and Tuberculosis",
  "Health Promotion",
  "Financial Management",
  "Reproductive and Child Health",
  "Management of Stores and Supplies",
  "Quality Assurance",
  "Standards, Protocols and Guidelines",
  "Management Practice",
  "Malaria Elimination",
  "HIV/AIDS Control",
  "Health Information Management",
  "Mental Health",
  "CHPS/MCHNP"
];

// ==========================
// 🔄 Populate Project Name Dropdown
// ==========================
const projectSelect = document.getElementById("project_name");
projectSelect.innerHTML = '<option value="">-- Select Project --</option>';
projectNames.forEach(name => {
  const option = document.createElement("option");
  option.value = name;
  option.textContent = name;
  projectSelect.appendChild(option);
});

// ==========================
// 🔄 Populate Facility Visited (Search Filter Dropdown)
// ==========================
document.getElementById("subMunicipalSearch").addEventListener("change", () => {
  const selectedSub = document.getElementById("subMunicipalSearch").value;
  const facilitySearch = document.getElementById("facilityVisitedSearch");

  facilitySearch.innerHTML = '<option value="">-- Select Facility --</option>';
  if (facilityMap[selectedSub]) {
    facilityMap[selectedSub].forEach(fac => {
      const option = document.createElement("option");
      option.value = fac;
      option.textContent = fac;
      facilitySearch.appendChild(option);
    });
  }
});

// ==========================
// 🏥 Auto-Populate Facilities & Location on Sub-Municipal Change (Edit Form)
// ==========================
document.getElementById("sub_municipal").addEventListener("change", () => {
  const subMunicipal = document.getElementById("sub_municipal").value;
  const facilitySelect = document.getElementById("facility_visited");
  const locationInput = document.getElementById("location");

  locationInput.value = subMunicipal;

  facilitySelect.innerHTML = '<option value="">-- Select Facility --</option>';
  if (facilityMap[subMunicipal]) {
    facilityMap[subMunicipal].forEach(facility => {
      const option = document.createElement("option");
      option.value = facility;
      option.textContent = facility;
      facilitySelect.appendChild(option);
    });
  }
});

// ==========================
// 🔍 Load Form Based on Search Filters
// ==========================
document.getElementById("loadBtn").addEventListener("click", async () => {
  const formType = document.getElementById("formTypeSearch").value;
  const monitoringNumber = document.getElementById("monitoringNumberSearch").value;
  const program = document.getElementById("programSearch").value;
  const subMunicipal = document.getElementById("subMunicipalSearch").value;
  const facilityVisited = document.getElementById("facilityVisitedSearch").value;

  if (!formType || !monitoringNumber || !program) {
    alert("❌ Please enter Monitoring Number, Form Type, and Program.");
    return;
  }

  try {
    const params = new URLSearchParams({
      form_type: formType,
      monitoring_number: monitoringNumber,
      program,
      sub_municipal: subMunicipal,
      facility_visited: facilityVisited
    });

    const response = await fetch(`http://localhost:5000/api/forms/search?${params}`);
    const data = await response.json();

    if (data.success && data.forms.length > 0) {
      populateFormForEditing(data.forms[0], data.questions);
    } else {
      alert("❌ No form found matching your criteria.");
    }
  } catch (error) {
    console.error("❌ Error fetching form:", error);
    alert("❌ Error loading form data.");
  }
});


// ... [unchanged sections remain the same above]

// ==========================
// 🧩 Populate Form for Editing
// ==========================
function populateFormForEditing(form, questions) {
  document.getElementById("editForm").style.display = "block";
  window.currentFormId = form.id;

  // === Metadata population ===
  document.getElementById("organisation_name").value = form.organisation_name;
  document.getElementById("project_name").value = form.project_name;
  document.getElementById("region").value = form.region;
  document.getElementById("sub_municipal").value = form.sub_municipal;

  // ✅ Populate Facility dropdown
  const facilitySelect = document.getElementById("facility_visited");
  facilitySelect.innerHTML = '<option value="">-- Select Facility --</option>';
  if (facilityMap[form.sub_municipal]) {
    facilityMap[form.sub_municipal].forEach(fac => {
      const option = document.createElement("option");
      option.value = fac;
      option.textContent = fac;
      facilitySelect.appendChild(option);
    });
  }
  facilitySelect.value = form.facility_visited;

  document.getElementById("location").value = form.location;
  document.getElementById("respondents").value = form.respondents;
  document.getElementById("monitoring_team").value = form.monitoring_team;
  document.getElementById("team_members").value = form.team_members;
  document.getElementById("general_comments").value = form.general_comments;

  // ✅ Render the questions table
  const container = document.getElementById("questionEditSection");
  container.innerHTML = "";

  const table = document.createElement("table");
  table.innerHTML = `
    <thead>
      <tr>
        <th>Qst. No.</th>
        <th>Question</th>
        <th>Answer</th>
        <th>Remarks</th>
        <th>Score</th>
      </tr>
    </thead>

    <tbody>
  ${questions.map(q => `
    <tr class="question-row" data-question-id="${q.question_id}">
      <td>${q.question_number}</td>
      <td>${q.question_text}</td>
      <td>
        <select class="answer-select">
          <option value="">-- Select --</option>
          <option ${q.answer === "Yes" ? "selected" : ""}>Yes</option>
          <option ${q.answer === "No" ? "selected" : ""}>No</option>
          <option ${q.answer === "NA" ? "selected" : ""}>NA</option>
        </select>
      </td>
      <td>
        <select class="remark-select">
          <option value="">-- Select --</option>
          <option ${q.remark === "Poor" ? "selected" : ""}>Poor</option>
          <option ${q.remark === "Credit" ? "selected" : ""}>Credit</option>
          <option ${q.remark === "Good" ? "selected" : ""}>Good</option>
          <option ${q.remark === "Better" ? "selected" : ""}>Better</option>
          <option ${q.remark === "Excellent" ? "selected" : ""}>Excellent</option>
        </select>
      </td>
      <td>
        <select class="score-select">
          <option value="">-- Select --</option>
          ${[0, 1, 2, 3, 4, 5].map(s => `<option ${q.score == s ? "selected" : ""}>${s}</option>`).join("")}
        </select>
      </td>
    </tr>
  `).join("")}
</tbody>

  `;
  container.appendChild(table);
}

// ==========================
// 📝 Handle Update (PUT)
// ==========================
document.getElementById("editForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  if (!window.currentFormId) {
    alert("❌ No form loaded to update.");
    return;
  }

  const formData = new FormData(e.target);
  const metadata = Object.fromEntries(formData.entries());

  const payload = {
    monitoring_number: metadata.monitoring_number || document.getElementById("monitoringNumberSearch").value,
    form_type: document.getElementById("formTypeSearch").value,
    program: document.getElementById("programSearch").value,
    organisation_name: metadata.organisation_name,
    project_name: document.getElementById("project_name").value,
    region: metadata.region,
    sub_municipal: metadata.sub_municipal,
    facility_visited: metadata.facility_visited,
    location: metadata.location,
    respondents: metadata.respondents,
    monitoring_team: metadata.monitoring_team,
    team_members: metadata.team_members,
    general_comments: metadata.general_comments,
    answers: []
  };

  // ✅ Get all question rows
  const questionRows = document.querySelectorAll(".question-row");

questionRows.forEach(row => {
  // ✅ Pull question_id from the row's data attribute instead of hidden input
  const question_id = row.dataset.questionId;

  const answer = row.querySelector(".answer-select").value;
  const remark = row.querySelector(".remark-select").value;
  const score = row.querySelector(".score-select").value;

  // ✅ Only push complete answers into the payload
  if (question_id && answer && remark && score !== "") {
    payload.answers.push({
      question_id: parseInt(question_id),
      answer,
      remark,
      score: parseInt(score)
    });
  }
});


  if (payload.answers.length !== questionRows.length) {
    alert("❌ Please complete all answer fields.");
    return;
  }

  console.log("🧾 Payload being sent to backend:", payload);

  try {
    const res = await fetch(`http://localhost:5000/api/forms/${window.currentFormId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    const result = await res.json();
    if (result.success) {
      alert("✅ Form updated successfully!");
    } else {
      alert("❌ Failed to update form.");
    }
  } catch (err) {
    console.error("❌ Network error:", err);
    alert("❌ Error updating form. Check console.");
  }
});










//2. Backup
// // ==========================
// // 🧩 Populate Form for Editing
// // ==========================
// function populateFormForEditing(form, questions) {
//   document.getElementById("editForm").style.display = "block";
//   window.currentFormId = form.id;

//   document.getElementById("organisation_name").value = form.organisation_name;
//   document.getElementById("project_name").value = form.project_name;
//   document.getElementById("region").value = form.region;
//   document.getElementById("sub_municipal").value = form.sub_municipal;

//   const facilitySelect = document.getElementById("facility_visited");
//   facilitySelect.innerHTML = '<option value="">-- Select Facility --</option>';
//   if (facilityMap[form.sub_municipal]) {
//     facilityMap[form.sub_municipal].forEach(fac => {
//       const option = document.createElement("option");
//       option.value = fac;
//       option.textContent = fac;
//       facilitySelect.appendChild(option);
//     });
//   }
//   facilitySelect.value = form.facility_visited;

//   document.getElementById("location").value = form.location;
//   document.getElementById("respondents").value = form.respondents;
//   document.getElementById("monitoring_team").value = form.monitoring_team;
//   document.getElementById("team_members").value = form.team_members;
//   document.getElementById("general_comments").value = form.general_comments;

//   const container = document.getElementById("questionEditSection");
//   container.innerHTML = "";

//   const table = document.createElement("table");
//   table.innerHTML = `
//     <thead>
//       <tr>
//         <th>Qst. No.</th>
//         <th>Question</th>
//         <th>Answer</th>
//         <th>Remarks</th>
//         <th>Score</th>
//       </tr>
//     </thead>
//     <tbody>
//       ${questions.map(q => `
//         <tr class="question-row">
//           <td>
//             ${q.question_number}
//             <input type="hidden" class="question-id" value="${q.question_id}" />
//           </td>
//           <td>${q.question_text}</td>
//           <td>
//             <select class="answer-select">
//               <option value="">-- Select --</option>
//               <option ${q.answer === "Yes" ? "selected" : ""}>Yes</option>
//               <option ${q.answer === "No" ? "selected" : ""}>No</option>
//               <option ${q.answer === "NA" ? "selected" : ""}>NA</option>
//             </select>
//           </td>
//           <td>
//             <select class="remark-select">
//               <option value="">-- Select --</option>
//               <option ${q.remark === "Poor" ? "selected" : ""}>Poor</option>
//               <option ${q.remark === "Credit" ? "selected" : ""}>Credit</option>
//               <option ${q.remark === "Good" ? "selected" : ""}>Good</option>
//               <option ${q.remark === "Better" ? "selected" : ""}>Better</option>
//               <option ${q.remark === "Excellent" ? "selected" : ""}>Excellent</option>
//             </select>
//           </td>
//           <td>
//             <select class="score-select">
//               <option value="">-- Select --</option>
//               ${[0, 1, 2, 3, 4, 5].map(s => `<option ${q.score == s ? "selected" : ""}>${s}</option>`).join("")}
//             </select>
//           </td>
//         </tr>
//       `).join("")}
//     </tbody>
//   `;
//   container.appendChild(table);
// }

// // ==========================
// // 📝 Handle Update (PUT)
// // ==========================
// document.getElementById("editForm").addEventListener("submit", async (e) => {
//   e.preventDefault();

//   if (!window.currentFormId) {
//     alert("❌ No form loaded to update.");
//     return;
//   }

//   const formData = new FormData(e.target);
//   const metadata = Object.fromEntries(formData.entries());

//   const payload = {
//     monitoring_number: metadata.monitoring_number || document.getElementById("monitoringNumberSearch").value,
//     form_type: document.getElementById("formTypeSearch").value,
//     program: document.getElementById("programSearch").value,
//     organisation_name: metadata.organisation_name,
//     project_name: document.getElementById("project_name").value,
//     region: metadata.region,
//     sub_municipal: metadata.sub_municipal,
//     facility_visited: metadata.facility_visited,
//     location: metadata.location,
//     respondents: metadata.respondents,
//     monitoring_team: metadata.monitoring_team,
//     team_members: metadata.team_members,
//     general_comments: metadata.general_comments,
//     answers: []
//   };

//   const questionRows = document.querySelectorAll(".question-row");

//   questionRows.forEach(row => {
//     const question_id = row.querySelector(".question-id")?.value;
//     const answer = row.querySelector(".answer-select").value;
//     const remark = row.querySelector(".remark-select").value;
//     const score = row.querySelector(".score-select").value;

//     if (question_id && answer && remark && score !== "") {
//       payload.answers.push({
//         question_id: parseInt(question_id),
//         answer,
//         remark,
//         score: parseInt(score)
//       });
//     }
//   });

//   if (payload.answers.length !== questionRows.length) {
//     alert("❌ Please complete all answer fields.");
//     return;
//   }

//   console.log("🧾 Payload being sent to backend:", payload);

//   try {
//     const res = await fetch(`http://localhost:5000/api/forms/${window.currentFormId}`, {
//       method: "PUT",
//       headers: { "Content-Type": "application/json" },
//       body: JSON.stringify(payload)
//     });

//     const result = await res.json();

//     if (result.success) {
//       alert("✅ Form updated successfully!");
//     } else {
//       alert("❌ Failed to update form.");
//     }
//   } catch (err) {
//     console.error("❌ Network error:", err);
//     alert("❌ Error updating form. Check console.");
//   }
// });





// // ==========================
// // 🏥 Facility Mapping
// // ==========================
// const facilityMap = {
//   "Kotobabi": ["Anthon Memorial Hospital", "Anthon Memorial Hospital Annex", "Effan Victory Clinic", "Life View Medical Hospital", 
//               "Anthon CHPS", "Bright Star CHPS", "Ebony Down CHPS", "Pigfarm CHPS", "Anthon Annex CHPS", "Great Gerraldo CHPS"
//               ],

//   "Accra New Town": ["Ghanuba Specialist Hospital", "Medylife Healthcare (Clinix)", "Mercy Ana’s Maternity Home", "Mission Clinic", 
//                     "Mustard Health Systems and", "Fertility Centre (Sape Agbo)", "Gift Medical Centre", "Apostolic CHPS", 
//                     "Mrs. Dua CHPS", "Ayidiki CHPS", "Wisdom CHPS"
//                     ],

//   "Alajo": ["Alajo Community Clinic", "Unfolding Glory Medical Centre", "Alajo Park CHPS", "Delape CHPS", "High Tension CHPS", 
//             "Pele CHPS", "Polo Park CHPS"
//           ],

//   "Kokomlemle": ["Entrance University Hospital", "Mallam Atta Government Clinic", "Mariestopes International Ghana", 
//                 "Salvation Army Anidasofie Clinic", "Holy Heights Clinic ", "Anidasofie CHPS", "De-youngsters CHPS", 
//                 "New Page CHPS", "Mallam Atta CHPS", "Tip Toe CHPS"
//                 ]
// };

// // ==========================
// // 📋 List of Project Names (15 forms)
// // ==========================
// const projectNames = [
//   "Clinical Care",
//   "Nutrition Services",
//   "Expanded Program of Immunisation, Surveillance and Tuberculosis",
//   "Health Promotion",
//   "Financial Management",
//   "Reproductive and Child Health",
//   "Management of Stores and Supplies",
//   "Quality Assurance",
//   "Standards, Protocols and Guidelines",
//   "Management Practice",
//   "Malaria Elimination",
//   "HIV/AIDS Control",
//   "Health Information Management",
//   "Mental Health",
//   "CHPS/MCHNP"
// ];

// // ==========================
// // 🔄 Populate Project Name Dropdown
// // ==========================
// const projectSelect = document.getElementById("project_name");
// projectSelect.innerHTML = '<option value="">-- Select Project --</option>';
// projectNames.forEach(name => {
//   const option = document.createElement("option");
//   option.value = name;
//   option.textContent = name;
//   projectSelect.appendChild(option);
// });


// // ==========================
// // 🔄 Populate Facility Visited (Search Filter Dropdown)
// // ==========================
// document.getElementById("subMunicipalSearch").addEventListener("change", () => {
//   const selectedSub = document.getElementById("subMunicipalSearch").value;
//   const facilitySearch = document.getElementById("facilityVisitedSearch");

//   // Clear previous options
//   facilitySearch.innerHTML = '<option value="">-- Select Facility --</option>';

//   // Populate new options if mapping exists
//   if (facilityMap[selectedSub]) {
//     facilityMap[selectedSub].forEach(fac => {
//       const option = document.createElement("option");
//       option.value = fac;
//       option.textContent = fac;
//       facilitySearch.appendChild(option);
//     });
//   }
// });

// // ==========================
// // 🏥 Auto-Populate Facilities & Location on Sub-Municipal Change (Edit Form)
// // ==========================
// document.getElementById("sub_municipal").addEventListener("change", () => {
//   const subMunicipal = document.getElementById("sub_municipal").value;
//   const facilitySelect = document.getElementById("facility_visited");
//   const locationInput = document.getElementById("location");

//   // 📍 Auto-fill location
//   locationInput.value = subMunicipal;

//   // 🔄 Reset and populate facility dropdown
//   facilitySelect.innerHTML = '<option value="">-- Select Facility --</option>';
//   if (facilityMap[subMunicipal]) {
//     facilityMap[subMunicipal].forEach(facility => {
//       const option = document.createElement("option");
//       option.value = facility;
//       option.textContent = facility;
//       facilitySelect.appendChild(option);
//     });
//   }
// });

// // ==========================
// // 🔍 Load Form Based on Search Filters
// // ==========================
// document.getElementById("loadBtn").addEventListener("click", async () => {
//   const formType = document.getElementById("formTypeSearch").value;
//   const monitoringNumber = document.getElementById("monitoringNumberSearch").value;
//   const program = document.getElementById("programSearch").value;
//   const subMunicipal = document.getElementById("subMunicipalSearch").value;
//   const facilityVisited = document.getElementById("facilityVisitedSearch").value;

//   if (!formType || !monitoringNumber || !program) {
//     alert("❌ Please enter Monitoring Number, Form Type, and Program.");
//     return;
//   }

//   try {
//     const params = new URLSearchParams({
//       form_type: formType,
//       monitoring_number: monitoringNumber,
//       program,
//       sub_municipal: subMunicipal,
//       facility_visited: facilityVisited
//     });

//     const response = await fetch(`http://localhost:5000/api/forms/search?${params}`);
//     const data = await response.json();

//     if (data.success && data.forms.length > 0) {
//       populateFormForEditing(data.forms[0], data.questions);
//     } else {
//       alert("❌ No form found matching your criteria.");
//     }
//   } catch (error) {
//     console.error("❌ Error fetching form:", error);
//     alert("❌ Error loading form data.");
//   }
// });

// // ==========================
// // 🧩 Populate Form for Editing
// // ==========================
// function populateFormForEditing(form, questions) {
//   document.getElementById("editForm").style.display = "block";
//   window.currentFormId = form.id;

//   // === Metadata fields ===
//   document.getElementById("organisation_name").value = form.organisation_name;
//   document.getElementById("project_name").value = form.project_name;
//   document.getElementById("region").value = form.region;
//   document.getElementById("sub_municipal").value = form.sub_municipal;

//   // 🏥 Trigger facility update and set facility value
//   const facilitySelect = document.getElementById("facility_visited");
//   facilitySelect.innerHTML = '<option value="">-- Select Facility --</option>';
//   if (facilityMap[form.sub_municipal]) {
//     facilityMap[form.sub_municipal].forEach(fac => {
//       const option = document.createElement("option");
//       option.value = fac;
//       option.textContent = fac;
//       facilitySelect.appendChild(option);
//     });
//   }
//   facilitySelect.value = form.facility_visited;

//   document.getElementById("location").value = form.location;
//   document.getElementById("respondents").value = form.respondents;
//   document.getElementById("monitoring_team").value = form.monitoring_team;
//   document.getElementById("team_members").value = form.team_members;
//   document.getElementById("general_comments").value = form.general_comments;

//   // === Render Introduction Questions Table ===
//   const container = document.getElementById("questionEditSection");
//   container.innerHTML = "";

//   const table = document.createElement("table");
//   table.innerHTML = `
//     <thead>
//       <tr>
//         <th>Qst. No.</th>
//         <th>Question</th>
//         <th>Answer</th>
//         <th>Remarks</th>
//         <th>Score</th>
//       </tr>
//     </thead>

//     <tbody>
//       ${questions.map((q, i) => `
//         <tr class="question-row">
//           <!-- ❗Hidden input inside a TD so it stays valid HTML -->
//           <td>
//             ${q.question_number}
//             <input type="hidden" class="question-id" value="${q.question_id}" />
//           </td>
//           <td>${q.question_text}</td>
//           <td>
//             <select class="answer-select">
//               <option value="">-- Select --</option>
//               <option ${q.answer === "Yes" ? "selected" : ""}>Yes</option>
//               <option ${q.answer === "No" ? "selected" : ""}>No</option>
//               <option ${q.answer === "NA" ? "selected" : ""}>NA</option>
//             </select>
//           </td>
//           <td>
//             <select class="remark-select">
//               <option value="">-- Select --</option>
//               <option ${q.remark === "Poor" ? "selected" : ""}>Poor</option>
//               <option ${q.remark === "Credit" ? "selected" : ""}>Credit</option>
//               <option ${q.remark === "Good" ? "selected" : ""}>Good</option>
//               <option ${q.remark === "Better" ? "selected" : ""}>Better</option>
//               <option ${q.remark === "Excellent" ? "selected" : ""}>Excellent</option>
//             </select>
//           </td>
//           <td>
//             <select class="score-select">
//               <option value="">-- Select --</option>
//               ${[0, 1, 2, 3, 4, 5].map(s => `<option ${q.score == s ? "selected" : ""}>${s}</option>`).join("")}
//             </select>
//           </td>
//         </tr>
//       `).join("")}
//     </tbody>

//   `;
//   container.appendChild(table);
// }


// // ==========================
// // 📝 Handle Update (PUT)
// // ==========================
// document.getElementById("editForm").addEventListener("submit", async (e) => {
//   e.preventDefault();

//   // ❗ Check if a form has been loaded before trying to update
//   if (!window.currentFormId) {
//     alert("❌ No form loaded to update.");
//     return;
//   }

//   // 📦 Extract form data
//   const formData = new FormData(e.target);
//   const metadata = Object.fromEntries(formData.entries());

//   // 🧾 Prepare the payload for the PUT request
//   const payload = {
//     monitoring_number: metadata.monitoring_number || document.getElementById("monitoringNumberSearch").value,
//     form_type: document.getElementById("formTypeSearch").value,
//     program: document.getElementById("programSearch").value,
//     organisation_name: metadata.organisation_name,
//     project_name: document.getElementById("project_name").value,
//     region: metadata.region,
//     sub_municipal: metadata.sub_municipal,
//     facility_visited: metadata.facility_visited,
//     location: metadata.location,
//     respondents: metadata.respondents,
//     monitoring_team: metadata.monitoring_team,
//     team_members: metadata.team_members,
//     general_comments: metadata.general_comments,
//     answers: [] // Will be filled with updated answers
//   };

//   // 🔁 Loop through question rows to extract answers
//   const questionRows = document.querySelectorAll(".question-row");

// questionRows.forEach(row => {
//   const question_id = row.querySelector(".question-id")?.value;
//   const answer = row.querySelector(".answer-select").value;
//   const remark = row.querySelector(".remark-select").value;
//   const score = row.querySelector(".score-select").value;

//   if (question_id && answer && remark && score !== "") {
//     payload.answers.push({
//       question_id: parseInt(question_id),
//       answer,
//       remark,
//       score: parseInt(score)
//     });
//   }
// });


//   // 🛑 Ensure all fields are filled before allowing submission
//   if (payload.answers.length !== questionRows.length) {
//     alert("❌ Please complete all answer fields.");
//     return;
//   }

//   console.log("🧾 Payload being sent to backend:", payload);

//   // 🔄 Send PUT request to backend to update form and answers
//   try {
//     const res = await fetch(`http://localhost:5000/api/forms/${window.currentFormId}`, {
//       method: "PUT",
//       headers: { "Content-Type": "application/json" },
//       body: JSON.stringify(payload)
//     });

//     if (!res.ok) {
//       const errorText = await res.text();
//       console.error("❌ Server error response:", errorText);
//       alert(`❌ Server responded with error: ${res.status}`);
//       return;
//     }

//     const result = await res.json();

//     if (result.success) {
//       alert("✅ Form updated successfully!");
//     } else {
//       alert("❌ Failed to update form.");
//     }

//   } catch (err) {
//     console.error("❌ Network or Fetch error:", err);
//     alert("❌ Error updating form. Check console.");
//   }
// });



// // //1.
// // // ==========================
// // // 📝 Handle Update (PUT)
// // // ==========================
// // document.getElementById("editForm").addEventListener("submit", async (e) => {
// //   e.preventDefault();

// //   if (!window.currentFormId) {
// //     alert("❌ No form loaded to update.");
// //     return;
// //   }

// //   const formData = new FormData(e.target);
// //   const metadata = Object.fromEntries(formData.entries());

// //   const payload = {
// //     monitoring_number: metadata.monitoring_number || document.getElementById("monitoringNumberSearch").value,
// //     form_type: document.getElementById("formTypeSearch").value,
// //     program: document.getElementById("programSearch").value,
// //     organisation_name: metadata.organisation_name,
// //     project_name: document.getElementById("project_name").value,
// //     region: metadata.region,
// //     sub_municipal: metadata.sub_municipal,
// //     facility_visited: metadata.facility_visited,
// //     location: metadata.location,
// //     respondents: metadata.respondents,
// //     monitoring_team: metadata.monitoring_team,
// //     team_members: metadata.team_members,
// //     general_comments: metadata.general_comments,
// //     answers: []
// //   };

// //   const questionRows = document.querySelectorAll(".question-row");

// //   questionRows.forEach(row => {
// //     const question_id = row.dataset.questionId;
// //     const answer = row.querySelector(".answer-select").value;
// //     const remark = row.querySelector(".remark-select").value;
// //     const score = row.querySelector(".score-select").value;

// //     if (question_id && answer && remark && score !== "") {
// //       payload.answers.push({
// //         question_id: parseInt(question_id),
// //         answer,
// //         remark,
// //         score: parseInt(score)
// //       });
// //     }
// //   });

// //   if (payload.answers.length !== questionRows.length) {
// //     alert("❌ Please complete all answer fields.");
// //     return;
// //   }
// //   console.log("🧾 Payload being sent to backend:", payload);

// //   try {
// //     const res = await fetch(`http://localhost:5000/api/forms/${window.currentFormId}`, {
// //       method: "PUT",
// //       headers: { "Content-Type": "application/json" },
// //       body: JSON.stringify(payload)
// //     });

// //     if (!res.ok) {
// //       const errorText = await res.text();
// //       console.error("❌ Server error response:", errorText);
// //       alert(`❌ Server responded with error: ${res.status}`);
// //       return;
// //     }

// //     const result = await res.json();

// //     if (result.success) {
// //       alert("✅ Form updated successfully!");
// //     } else {
// //       alert("❌ Failed to update form.");
// //     }
// //   } catch (err) {
// //     console.error("❌ Network or Fetch error:", err);
// //     alert("❌ Error updating form. Check console.");
// //   }
// // });
